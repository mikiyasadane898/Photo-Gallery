document.addEventListener("DOMContentLoaded", function() {
    const galleryItems = document.querySelectorAll(".gallery-item img");
    const lightbox = document.getElementById("lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    const lightboxDesc = document.getElementById("lightbox-desc");
    const close = document.querySelector(".close");
    const leftButton = document.createElement('button');
    const rightButton = document.createElement('button');
    let currentIndex = 0;

    leftButton.innerHTML = '&#10094;';
    rightButton.innerHTML = '&#10095;';
    leftButton.classList.add('scroll-button', 'left');
    rightButton.classList.add('scroll-button', 'right');

    galleryItems.forEach((item, index) => {
        item.addEventListener("click", function() {
            currentIndex = index;
            displayImage(currentIndex);
            document.body.appendChild(leftButton);
            document.body.appendChild(rightButton);
        });
    });

    close.addEventListener("click", function() {
        lightbox.classList.remove("active");
        document.body.removeChild(leftButton);
        document.body.removeChild(rightButton);
    });

    lightbox.addEventListener("click", function(event) {
        if (event.target !== lightboxImg && event.target !== lightboxDesc) {
            lightbox.classList.remove("active");
            document.body.removeChild(leftButton);
            document.body.removeChild(rightButton);
        }
    });

    leftButton.addEventListener('click', function() {
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : galleryItems.length - 1;
        displayImage(currentIndex);
    });

    rightButton.addEventListener('click', function() {
        currentIndex = (currentIndex < galleryItems.length - 1) ? currentIndex + 1 : 0;
        displayImage(currentIndex);
    });

    function displayImage(index) {
        lightboxImg.src = galleryItems[index].src;
        lightboxDesc.textContent = galleryItems[index].nextElementSibling.textContent;
        lightbox.classList.add("active");
    }
});
